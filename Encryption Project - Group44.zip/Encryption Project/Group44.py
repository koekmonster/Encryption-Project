#Stefan Koekemoer 41734386
#Ethan Hamilton 43986749
#Heindrich Burger 37818430
#John Crouse 37489917
from Cryptodome.Cipher import AES
from Cryptodome import Random
from Cryptodome.Util import Padding
import os
import zipfile
import tkinter as tk
from tkinter import filedialog
from PIL import Image
import base64

AES_IV = Random.new().read(AES.block_size)
AES_KEY = b'ThisIsASecretKey'

# Create a tkinter window
root = tk.Tk()
root.title('File Encryptor/Decryptor')
root.configure(bg="blue")

# Define the function to encrypt a file
def encrypt_file(file_path):
    with open(file_path, 'rb') as f:
        data = f.read()
        
    # Pad the data
    pad_data = pad(data)

    #AES_KEY = key_entry.get().encode('utf-8')
    #AES_KEY = AES_KEY[:32].ljust(32, b'\0')
   
    # Create the cipher object
    cipher = AES.new(AES_KEY, AES.MODE_CBC, IV=AES_IV)

    # Encrypt the data
    encrypt_data = cipher.encrypt(pad_data)

    # Prepend the IV to the encrypted data
    encrypt_data = AES_IV + encrypt_data

   
    
    # Return the encrypted data as bytes
    return encrypt_data

# Define the function to decrypt a file
def decrypt_file(file_path):
    with open(file_path, 'rb') as f:
        encrypt_data = f.read()
        original_text['text'] = encrypt_data
    # Get the IV from the encrypted data
    AES_IV = encrypt_data[:16]

    # Get the key from the user
    #AES_KEY = key_entry.get().encode('utf-8')
   #AES_KEY = AES_KEY[:32].ljust(32, b'\0') 

    # Create the cipher object
    cipher_text = AES.new(AES_KEY, AES.MODE_CBC, IV=AES_IV)

    # Decrypt the data and remove the padding
    decrypt_data = cipher_text.decrypt(encrypt_data[16:])
    unpadded_data = unpad(decrypt_data)
    
    
    decrypt_file_path = os.path.splitext(file_path)[0] + '_decryptedAES' + os.path.splitext(file_path)[1]
    with open(decrypt_file_path, 'wb') as f:
        f.write(AES_IV + decrypt_data) 
    # Return the decrypted data as a string
    return unpadded_data

# Helper function to pad the data
def pad(data):
    block_size = AES.block_size
    padding_size = block_size - len(data) % block_size
    padding = bytes([padding_size] * padding_size)
    return data + padding

# Helper function to remove the padding
def unpad(data):
    padding_size = data[-1]
    return data[:-padding_size]


# Define the function to encrypt a zipfile
def encrypt_zipfile(zipfile_path):
    encrypted_files = []

    # Iterate over the files in the zipfile
    with zipfile.ZipFile(zipfile_path, 'r') as zipf:
        for file_path in zipf.namelist():
            with zipf.open(file_path, 'r') as f:
                data = f.read()

            # Encrypt the data using AES
            encrypted_data = encrypt_file(data)

            # Add the encrypted data to the list of encrypted files
            encrypted_files.append((file_path, encrypted_data))

    # Return the list of encrypted files
    return encrypted_files

# Define the function to handle the browse button
def browse_file():
    # Show a file dialog to select a file
    file_path = filedialog.askopenfilename()

    # Set the selected file path in the entry widget
    file_entry.delete(0, tk.END)
    file_entry.insert(0, file_path)
    
def encrypt_file_path(file_path):
    with open(file_path, 'rb') as f:
        data = f.read()
        original_text['text'] = data
    # Pad the data
    padded_data = pad(data)

    # Create the cipher object
    cipher = AES.new(AES_KEY, AES.MODE_CBC, IV=AES_IV)

    # Encrypt the data
    encrypted_data = cipher.encrypt(padded_data)

    # Save the encrypted data to a new file
    encrypted_file_path = os.path.splitext(file_path)[0] + '_encryptedAES' + os.path.splitext(file_path)[1]
    with open(encrypted_file_path, 'wb') as f:
        f.write(AES_IV + encrypted_data)

    return encrypted_file_path

# Define the function to handle the encrypt button
def encrypt_file_button():
    # Get the selected file path from the entry widget
    file_path = file_entry.get()
    method = method_var.get()
    key = key_entry.get()
    
    if method == 'Own Algorithm':
        encrypt_file_own_algorithm(file_path, key)
        # Delete the original unencrypted file
        os.remove(file_path)
    # Encrypt the file or zipfile
    else:
        #test to see what file it is
        if file_path.endswith('.jpg') or file_path.endswith('.png') or file_path.endswith('.pptx') or file_path.endswith('.txt'):
            #encrypt data and the file path
            encrypted_data = encrypt_file(file_path)
            encrypt_path = encrypt_file_path(file_path)
            succesfull = 'Data has been encrypted succesfully'
            string = encrypted_data + '\n'.encode('utf-8') + succesfull.encode('utf-8')
            result_text['text'] = string
             # Delete the original unencrypted file
            os.remove(file_path)
        elif file_path.endswith('.zip'):
            encrypted_files = encrypt_zipfile(file_path)
            for file_path, encrypted_data in encrypted_files:
                result_label['text'] += f'Encrypted file {file_path}:\n{encrypted_data.hex()}\n'
            
# Define the function to decrypt a zipfile
def decrypt_zipfile(zipfile_path):
    decrypted_files = []

    # Extract the encrypted files from the zipfile
    with zipfile.ZipFile(zipfile_path, 'r') as zipf:
        for file_path in zipf.namelist():
            with zipf.open(file_path, 'r') as f:
                encrypted_data = f.read()

            # Decrypt the data using AES
            ciphertext = AES.new(AES_KEY, AES.MODE_CBC, IV=AES_IV)
            decrypted_data = ciphertext.decrypt(encrypted_data)

            # Add the decrypted data to the list of decrypted files
            decrypted_files.append((file_path, decrypted_data))

    # Return the list of decrypted files
    return decrypted_files

# Define the function to handle the browse button
def browse_file():
    # Show a file dialog to select a file
    file_path = filedialog.askopenfilename()

    # Set the selected file path in the entry widget
    file_entry.delete(0, tk.END)
    file_entry.insert(0, file_path)

# Define the function to handle the decrypt button
def decrypt_file_button():
    # Get the selected file path from the entry widget
    file_path = file_entry.get()
    method = method_var.get()
    key = key_entry.get()
    
    
    if method == 'Own Algorithm':
        decrypt_file_own_algorithm(file_path, key) 
    else:
    # Decrypt the file or zipfile
        if file_path.endswith('.jpg') or file_path.endswith('.png') or file_path.endswith('.pptx') or file_path.endswith('.txt'):
            decrypted_data = decrypt_file(file_path)
            succesfull = 'Data has been decrypted succesfully'
            string = decrypted_data + '\n'.encode('utf-8')+ succesfull.encode('utf-8')
            result_text['text'] = string.decode('utf-8')
        elif file_path.endswith('.zip'):
            decrypted_files = decrypt_zipfile(file_path)
            for file_path, decrypted_data in decrypted_files:
                result_label['text'] += f'Decrypted file {file_path}:\n{decrypted_data.decode("utf-8")}\n'
            
            
def decrypt_file_own_algorithm(file_path, key):
    with open(file_path, 'rb') as f:
        data = f.read()
        #test different file types to ensure that correct decryption is used
        if file_path.endswith('.txt'):
            plaintext = decrypt_caesar_cipher(data, key)
            succesfull = 'Data has been decrypted succesfully'
            string = decrypted_data + '\n'.encode('utf-8') + plaintext.encode('utf-8')
            result_text['text'] = plaintext
        elif file_path.endswith('.pptx'):
            plaintext = decrypt_xor_cipher(data, key)
            result_text.configure(text='')
        elif file_path.endswith('.jpg') or file_path.endswith('.png'):
            plaintext = decrypt_image(data, key)
            result_text.configure(text='')
        elif file_path.endswith('.zip'):
            plaintext = decrypt_zipfile(data, key)
            result_text['text'] = 'Decryption successful. Extracted files are in the same directory as the encrypted file.'
        else:
            raise ValueError('Unsupported file type')
    decrypted_file_path = os.path.splitext(file_path)[0] + '_decryptedOWN' + os.path.splitext(file_path)[1]
    with open(decrypted_file_path, 'wb') as f:
        if isinstance(plaintext, bytes):
            f.write(plaintext)
      

        
def decrypt_caesar_cipher(data, key):
    """
    Encrypts the given data using the Caesar Cipher with the given key.
    """
    results = bytearray()
    for byte in data:
        shift = (byte - int(key)) % 256
        results.append(shift)
    return results

def decrypt_xor_cipher(data, key):
    """
    Decrypts the given data using the XOR Cipher with the given key.
    """
    key_bytes = bytearray(key.encode('utf-8'))
    results = bytearray()
    for i in range(len(data)):
        byte = data[i] ^ key_bytes[i % len(key_bytes)]
        results.append(byte)
    return results
        

def decrypt_image(data, key):
    """
    Decrypts the image data using a simple XOR cipher with the given key.
    """
    key = bytes(key, 'utf-8')
    decrypted_data = bytearray()
    for i in range(len(data)):
        decrypted_byte = data[i] ^ key[i % len(key)]
        decrypted_data.append(decrypted_byte)
    decrypted_image = Image.frombytes('RGB', (256, 256), bytes(decrypted_data))
    return decrypted_image

                


def encrypt_file_own_algorithm(file_path, key):
    with open(file_path, 'rb') as file:
        data = file.read()
        original_text.configure(text=data)
    key = key_entry.get()
    with open(file_path, 'rb') as f:
        data = f.read()
        #test different file types to ensure correct method is used to encode file
        if file_path.endswith('.txt'):
            cipher = encrypt_caesar_cipher(data, key)
            result_text['text'] = cipher.decode('utf-8')
        elif file_path.endswith('.pptx'):
            cipher = encrypt_xor_cipher(data, key)
            encrypted_data = base64.b64encode(cipher)
            result_text['text'] = encrypted_data.decode('ascii')
        elif file_path.endswith('.jpg') or file_path.endswith('.png'):
            cipher = encrypt_image(data, key)
            result_text['text'] = cipher.hex()
        elif file_path.endswith('.zip'):
            cipher = encrypt_zipfile(data, key)
            result_text['text'] = cipher.hex()
        else:
            raise ValueError('Unsupported file type')
    encrypted_file_path = os.path.splitext(file_path)[0] + '_encryptedOWN' + os.path.splitext(file_path)[1]
    with open(encrypted_file_path, 'wb') as f:
        f.write(cipher)


def encrypt_caesar_cipher(data, key):
    """
    Encrypts the given data using the Caesar Cipher with the given key.
    """
    results = bytearray()
    for byte in data:
        shift = (byte + int(key)) % 256
        results.append(shift)
    return results

def encrypt_xor_cipher(data, key):
    """
    Encrypts the given data using the XOR Cipher with the given key.
    """
    key_bytes = bytearray(key.encode('utf-8'))
    results = bytearray()
    for i in range(len(data)):
        byte = data[i] ^ key_bytes[i % len(key_bytes)]
        results.append(byte)
    return results

def encrypt_image(data, key):
    """
    Encrypts the given image data using a simple XOR Cipher with the given key.
    """
    image = Image.frombytes('RGB', (len(data) // 3, 1), bytes(data))
    key_bytes = bytearray(key.encode('utf-8'))
    pixel_data = list(image.getdata())
    for i in range(len(pixel_data)):
        pixels = list(pixel_data[i])
        for j in range(len(pixels)):
            pixels[j] ^= key_bytes[j % len(key_bytes)]
        pixel_data[i] = tuple(pixels)
    encrypted_image = Image.new('RGB', image.size)
    encrypted_image.putdata(pixel_data)
    encrypted_data = bytearray()
    for pixel in pixel_data:
        for value in pixel:
            encrypted_data.append(value)
    return encrypted_data

def encrypt_zipfile(data, key):
    """
    Encrypts the given zip file data using a simple XOR Cipher with the given key.
    """
    with zipfile.ZipFile(io.BytesIO(data), 'r') as zf:
        filenames = zf.namelist()
        with io.BytesIO() as output:
            with zipfile.ZipFile(output, 'w') as encrypted_zf:
                for filename in filenames:
                    file_data = zf.read(filename)
                    encrypted_data = encrypt_xor_cipher(file_data, key)
                    encrypted_zf.writestr(filename, encrypted_data)
            encrypted_data = output.getvalue()
    return encrypted_data

 
    # Define the function to reset the program
def reset_program():
    # Clear the file entry widget
    file_entry.delete(0, tk.END)

    # Reset the method dropdown to "AES"
    method_var.set("AES")

    # Clear the key entry widget
    key_entry.delete(0, tk.END)

    # Reset the option variable to "None"
    option.set("None")

    # Clear the original and result labels
    original_text['text'] = ''
    result_text['text'] = ''

# Create a reset button
reset_button = tk.Button(root, text="Reset", command=reset_program)
reset_button.grid(row=10, column=1)
reset_button.configure(bg="Skyblue")
 #Create a file entry widget and a browse button
file_label = tk.Label(root, text="File:")
file_label.grid(row=0, column=0, sticky="w")
file_label.configure(bg="Skyblue")

file_entry = tk.Entry(root)
file_entry.grid(row=0, column = 1)
file_entry.configure(bg="Skyblue")

browse_button = tk.Button(root, text='Browse', command=browse_file)
browse_button.grid(row=0, column = 2)
browse_button.configure(bg="Skyblue")



# Create a dropdown widget for selecting the encryption algorithm
method_label = tk.Label(root, text="Method:")
method_label.grid(row=1, column=0, sticky="w")
method_label.configure(bg="Skyblue")
method_var = tk.StringVar(root)
method_var.set("AES")
method_dropdown = tk.OptionMenu(root, method_var, "AES", "Own Algorithm")
method_dropdown.grid(row=1, column=1)
method_dropdown.configure(bg="Skyblue")

# Create a label widget for the key entry
key_label = tk.Label(root, text="Key:")
key_label.grid(row=2, column=0, sticky="w")
key_label.configure(bg="Skyblue")

# Create an entry widget for the key
key_entry = tk.Entry(root,show='*')
key_entry.grid(row=2, column=1)


# Create buttons for encrypt and decrypt

encrypt_button = tk.Button(root, text="Encrypt", command=encrypt_file_button)
encrypt_button.grid(row=3, column=1)
encrypt_button.configure(bg="Skyblue")

decrypt_button = tk.Button(root, text="Decrypt", command=decrypt_file_button)
decrypt_button.grid(row=3, column=2)
decrypt_button.configure(bg="Skyblue")

# Original and Result Labels
original_label = tk.Label(root, text="Original File:")
original_label.grid(row=4, column=0, sticky="w")
original_label.configure(bg="Skyblue")

original_text = tk.Label(root, height=15, width=30)
original_text.grid(row=5, column=1, rowspan=5)

result_label = tk.Label(root, text="Result:")
result_label.grid(row=4, column=2, sticky="w")
result_label.configure(bg="Skyblue")

result_text = tk.Label(root, height=15, width=35)
result_text.grid(row=5, column=3, rowspan=5)


# Run and Close Buttons


close_button = tk.Button(root, text="Close", command=root.destroy)
close_button.grid(row=10, column=4, pady=10)
close_button.configure(bg = "Red")


root.mainloop()
